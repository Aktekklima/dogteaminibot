# main.py
print('DogteaMinerBot çalışıyor!')