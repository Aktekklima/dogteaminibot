# DogteaMinerBot
Bu bot Replit üzerinde çalıştırılmak üzere hazırlanmıştır.