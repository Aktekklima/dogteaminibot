# config.py
TOKEN = 'YOUR_BOT_TOKEN'
CHANNEL_LINK = 'https://t.me/dogteaminerbotnews'